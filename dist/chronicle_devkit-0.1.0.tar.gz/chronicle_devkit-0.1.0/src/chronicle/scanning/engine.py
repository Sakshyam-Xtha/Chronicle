from pathlib import Path
from chronicle.scanning.scanners.base import Scanner
from chronicle.storage.models import Observation
from .context import ScanContext

class ScanEngine:
    def __init__(self,project_root:Path,scanners:list[Scanner]) -> None:
        self.project_root = project_root
        self.scanners = scanners
        
    def scan(self,contexts:list[ScanContext]) -> list[Observation]:
        observation:list[Observation] = []
        for scanner in self.scanners:
            observation.extend(scanner.scan(contexts=contexts))
        
        return observation